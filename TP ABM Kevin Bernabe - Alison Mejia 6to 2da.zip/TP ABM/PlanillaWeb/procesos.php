<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.3.0/mdb.min.css" rel="stylesheet" />
    

    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">

    <title>Gral. Jose de San Martin</title>

</head>
  <body style="background-color: #0F2D47;">
    <?php
    session_start();

    

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //LOGIN
        
        if (isset($_POST["login_email"]) && isset($_POST["login_contraseña"])) {
            $email = htmlspecialchars($_POST["login_email"]);
            $contraseña = htmlspecialchars($_POST["login_contraseña"]);

            include("conexion.php");

            $hash = md5($contraseña);

            $consulta_sql = "SELECT * FROM usuario WHERE email = ? and contrasenia = ?";
            $statement = $conexion->prepare($consulta_sql);
            $statement->bind_param("ss", $email, $hash);
            $statement->execute();
            $resultado = $statement->get_result();

            if ($resultado->num_rows > 0) {
                $row = $resultado->fetch_assoc();
                $_SESSION['ID'] = $row["ID"];
                $_SESSION["email"] = $row["email"];
                $_SESSION["nombre"] = $row["nombre"];
                $_SESSION["apellido"] = $row["apellido"];
                $_SESSION["fnacimiento"] = $row["fnacimiento"];
                $_SESSION["genero"] = $row["genero"];
                $_SESSION["telefono"] = $row["telefono"];
                $_SESSION["id_rol"] = $row["id_rol"];
                $cuenta = 1;
                $_SESSION['cuenta'] = $cuenta;

                header("Location: años.php");
                exit();
            } else {
                echo '<div class="position-absolute top-50 start-50 translate-middle">
                        <div class="card" style="width: 400px;">
                            <div class="card-body">
                                <h5 class="card-title">Nombre de usuario y/o contraseña incorrectos. Intente nuevamente.</h5> 
                                <br>
                                <a href="#" onclick="history.back(); return false;" class="btn btn-danger">Volver</a>
                                <br><br>
                                <h5 class="card-title">También puede intentar registrarse si aún no lo está.</h5>
                                <br>
                                <a href="registro.php" class="btn btn-success">Registrarse</a>
                            </div>
                        </div>
                    </div>';
            }
        }

        //REGISTRO
        
        if (isset($_POST["registro_nombre"]) && isset($_POST["registro_apellido"]) && isset($_POST["registro_fnacimiento"]) && isset($_POST["registro_genero"]) && isset($_POST["registro_email"]) && isset($_POST["registro_telefono"]) && isset($_POST["registro_contraseña"]) && isset($_POST["registro_confirmacion_contraseña"])) {
            $nombre = htmlspecialchars($_POST['registro_nombre']);
            $apellido = htmlspecialchars($_POST['registro_apellido']);
            $fnacimiento = htmlspecialchars($_POST['registro_fnacimiento']);
            $genero = htmlspecialchars($_POST['registro_genero']);
            $email = htmlspecialchars($_POST['registro_email']);
            $telefono = htmlspecialchars($_POST['registro_telefono']);
            $contraseña = htmlspecialchars($_POST['registro_contraseña']);
            $confirmacion_contraseña = htmlspecialchars($_POST['registro_confirmacion_contraseña']);

            include("conexion.php");

            if ($contraseña === $confirmacion_contraseña) {
                $consulta = "SELECT * FROM usuario WHERE email = ?";
                $statement = $conexion->prepare($consulta);
                $statement->bind_param("s", $email);
                $statement->execute();
                $resultado = $statement->get_result();

                if ($resultado->num_rows > 0) {
                    echo '<div class="position-absolute top-50 start-50 translate-middle">
                            <div class="card" style="width: 400px;">
                                <div class="card-body">
                                    <h5 class="card-title">El correo electrónico ya está registrado. Por favor, utiliza otro correo electrónico.</h5>
                                    <a href="#" onclick="history.back(); return false;" class="btn btn-danger">Volver</a>
                                </div>
                            </div>
                        </div>';
                } else {
                    $hash = md5($contraseña);

                    $insert_sql = "INSERT INTO usuario (nombre, apellido, fnacimiento, genero, email, telefono, contrasenia, id_rol) VALUES ('$nombre', '$apellido', '$fnacimiento', '$genero', '$email', '$telefono', '$hash', 3 /* Empezar con rol estandar de alumno */)";

                    if ($conexion->query($insert_sql) === TRUE) {
                        echo '<div class="position-absolute top-50 start-50 translate-middle">
                                    <div class="card" style="width: 400px;">
                                        <div class="card-body">
                                            <h5 class="card-title">Cuenta registrada correctamente! Inicie sesión</h5>
                                            <a href="Login.php" class="btn btn-primary">Iniciar Sesión</a>
                                        </div>
                                    </div>
                                </div>';
                    } else {
                        echo '<div class="position-absolute top-50 start-50 translate-middle">
                                    <div class="card" style="width: 400px;">
                                        <div class="card-body">
                                            <h5 class="card-title">Error al registrar su cuenta! Intente de nuevo.</h5>
                                            <a href="#" onclick="history.back(); return false;" class="btn btn-danger">Volver</a>
                                        </div>
                                    </div>
                                </div>';
                    }
                }
            } else {
                echo '<div class="position-absolute top-50 start-50 translate-middle">
                                <div class="card" style="width: 400px;">
                                    <div class="card-body">
                                        <h5 class="card-title">Las contraseñas no coinciden! Intente otra vez.</h5>
                                        <a href="#" onclick="history.back(); return false;" class="btn btn-danger">Volver</a>
                                    </div>
                                </div>
                            </div>';
            }
        }

        if (isset($_POST["contraseña"])) {
            $contraseña = htmlspecialchars($_POST["contraseña"]);

            include("conexion.php");

            $hash = md5($contraseña);

            $consulta_sql = "SELECT * FROM usuario WHERE email = ? and contrasenia = ?";
            $statement = $conexion->prepare($consulta_sql);
            $statement->bind_param("ss", $_SESSION['email'], $hash);
            $statement->execute();
            $resultado = $statement->get_result();

            if ($resultado->num_rows > 0) {
                
                header("Location: editar_datos.php");
                exit();
            } else {
                echo '<div class="position-absolute top-50 start-50 translate-middle">
                        <div class="card" style="width: 400px;">
                            <div class="card-body">
                                <h5 class="card-title">Contraseña Incorrecta. Intente nuevamente.</h5> 
                                <br>
                                <a href="#" onclick="history.back(); return false;" class="btn btn-danger">Volver</a>
                            </div>
                        </div>
                    </div>';
            }
        }

        //Editar campos

        if (isset($_POST["editar_email"]) && isset($_POST["editar_telefono"]) && isset($_POST["editar_contraseña"]) && isset($_POST["editar_confirmacion_contraseña"])) {
            $email = htmlspecialchars($_POST['editar_email']);
            $telefono = htmlspecialchars($_POST['editar_telefono']);
            $contraseña = htmlspecialchars($_POST['editar_contraseña']);
            $confirmacion_contraseña = htmlspecialchars($_POST['editar_confirmacion_contraseña']);
        
            $contraseña = trim($contraseña);
            $confirmacion_contraseña = trim($confirmacion_contraseña);
        
            echo '<div class="position-absolute top-50 start-50 translate-middle">
                    <div class="card" style="width: 400px;">
                        <div class="card-body">
                            <h5 class="card-title">Resumen de Edición</h5>
                            <ul class="list-unstyled">';
        
            include("conexion.php");

            if ($_SESSION['email'] !== $email) {
                $consulta = "SELECT * FROM usuario WHERE email = ?";
                $statement = $conexion->prepare($consulta);
                $statement->bind_param("s", $email);
                $statement->execute();
                $resultado = $statement->get_result();
        
                if ($resultado->num_rows > 0) {
                    echo '<li class="mb-1"><i class="fas fa-circle-xmark me-2 text-danger"></i>El correo ingresado ya está registrado por otro usuario, intente nuevamente mas tarde.</li>';
                } else {
                    
                    $update_sql = "UPDATE usuario SET email = '$email' WHERE ID = " . $_SESSION['ID'];
                    if ($conexion->query($update_sql) === TRUE) {
                        $_SESSION['email'] = $email; 
                        echo '<li class="mb-1"><i class="fas fa-check-circle me-2 text-success"></i>El correo ha sido actualizado correctamente.</li>';
                    }
                }
            } else {
                echo '<li class="mb-1"><i class="fas fa-circle-exclamation me-2 text-warning"></i>El correo ingresado es el mismo que tenía, no se han realizado cambios.</li>';
            }
        
            if ($_SESSION['telefono'] !== $telefono) {
                $update_sql = "UPDATE usuario SET telefono = '$telefono' WHERE ID = " . $_SESSION['ID'];
                if ($conexion->query($update_sql) === TRUE) {
                    $_SESSION['telefono'] = $telefono; 
                    echo '<li class="mb-1"><i class="fas fa-check-circle me-2 text-success"></i>El teléfono ha sido actualizado correctamente.</li>';
                }
            } else {
                echo '<li class="mb-1"><i class="fas fa-circle-exclamation me-2 text-warning"></i>El teléfono ingresado es el mismo que tenía, no se han realizado cambios.</li>';
            }

            if (!empty($contraseña)) {
                if ($contraseña === $confirmacion_contraseña) {
                    $hash = md5($contraseña);

                    $update_sql = "UPDATE usuario SET contrasenia = '$hash' WHERE ID = " . $_SESSION['ID'];
                    if ($conexion->query($update_sql) === TRUE) {
                        echo '<li class="mb-1"><i class="fas fa-check-circle me-2 text-success"></i>La contraseña ha sido cambiada correctamente.</li>';
                    }
                } else {
                    echo '<li class="mb-1"><i class="fas fa-circle-xmark me-2 text-danger"></i>Las contraseñas no coinciden. No se han relizado cambios. Intente nuevamente.</li>';
                }
            } else {
                echo '<li class="mb-1"><i class="fas fa-circle-exclamation me-2 text-warning"></i>No se ha proporcionado una nueva contraseña, por ende no se han realizado cambios.</li>';
            }
        
            echo '  </ul>
                    <p>Puede realizar esta accion ingresando nuevamente donde lo hizo previamente a estas acciones.</p>
                    <a href="años.php" class="btn btn-success">Volver al Inicio</a>
                </div>
            </div>
        </div>';
        }

        //Formulario de Recuperar Contraseña

        if (isset($_POST["token"])) {
            $token = htmlspecialchars($_POST["token"]);
        
            include("conexion.php");
        
            $hash_token = md5($token);

            //Consulto que el token que se haya asignado anterior a este intento no haya caducado por el tiempo. 

            $consulta_dispo = "SELECT token, creacion FROM tokens WHERE token = ?";
            $statement_dispo = $conexion->prepare($consulta_dispo);
            $statement_dispo->bind_param("s", $hash_token);
            $statement_dispo->execute();
            $resultado_dispo = $statement_dispo->get_result();
                
            if ($resultado_dispo->num_rows === 1) {
                $fila = $resultado_dispo->fetch_assoc();
                $token_bd = $fila['token'];
                $creacion = new DateTime($fila['creacion']);
                $now = new DateTime();

                $interval = $now->diff($creacion);
                $minutos_pasados = $interval->i;

                if ($minutos_pasados >= 30) {
                    //pasados 30 minutos, se elimina el token
                    $eliminar_query = "DELETE FROM tokens WHERE usuario_id = ? AND email = ?";
                    $eliminar_statement = $conexion->prepare($eliminar_query);
                    $eliminar_statement->bind_param("is", $row['ID'], $email);
                    $eliminar_statement->execute();
                } 
            }
        
            $consulta_sql = "SELECT * FROM tokens WHERE token = ? AND usado = 0";
            $statement = $conexion->prepare($consulta_sql);
            $statement->bind_param("s", $hash_token);
            $statement->execute();
            $resultado = $statement->get_result();
        
            if ($resultado->num_rows > 0) {
                $row = $resultado->fetch_assoc();
        
                $email = $row["email"];

                $consulta_usuario = "SELECT * FROM usuario WHERE email = ?";
                $statement_usuario = $conexion->prepare($consulta_usuario);
                $statement_usuario->bind_param("s", $email);
                $statement_usuario->execute();
                $resultado_usuario = $statement_usuario->get_result();
        
                if ($resultado_usuario->num_rows > 0) {
                    $usuario = $resultado_usuario->fetch_assoc();
                    $_SESSION['ID'] = $usuario["ID"];
                    $_SESSION["email"] = $usuario["email"];
                    $_SESSION["nombre"] = $usuario["nombre"];
                    $_SESSION["apellido"] = $usuario["apellido"];
                    $_SESSION["fnacimiento"] = $usuario["fnacimiento"];
                    $_SESSION["genero"] = $usuario["genero"];
                    $_SESSION["telefono"] = $usuario["telefono"];
                    $_SESSION["DNI"] = $usuario["DNI"];

                    $eliminar_query = "DELETE FROM tokens WHERE usuario_id = ? AND email = ?";
                    $eliminar_statement = $conexion->prepare($eliminar_query);
                    $eliminar_statement->bind_param("is", $_SESSION['ID'], $email);
                    $eliminar_statement->execute();
        
                    header("Location: editar_datos.php");
                    exit();
                } else {
                    echo "El usuario no existe en la tabla de usuarios.";
                }
            } else {
                echo '<div class="position-absolute top-50 start-50 translate-middle">
                        <div class="card" style="width: 400px;">
                            <div class="card-body">
                                <h5 class="card-title">Token inválido o ya ha sido utilizado.</h5> 
                                <br>
                                <a href="#" onclick="history.back(); return false;" class="btn btn-danger">Volver</a>
                            </div>
                        </div>
                    </div>';
            }
        }     
        
    }


    ?>
</body>
</html>