<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
    rel="stylesheet"
    />

    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">

    <title>Gral. Jose de San Martin</title>
</head>
<body style="background-color: #0F2D47;">
    <form action="procesos.php" class="intro" method="POST">
        <div class="container my-4">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card" style="border-radius: 1rem; background-color:#307AB4;">
                        <div class="card-body p-5 text-center">

                            <div class="my-md-5">
                                <div class="position-absolute top-0 start-0" style="width:120px; margin-left: 20px; margin-top: 20px;">
                                    <a href="Inicio.php"><i style="color:#D4C0A5; float:left;" class="fas fa-angles-left fa-2x"></i><h3 style="color:#D4C0A5;" >Volver</h3></a>
                                </div>
                                        
                                <h1 style="color:#D4C0A5;" class="fw-bold mb-0"><em>¡Bienvenido!</em></h1>
                                <i style="color:#D4C0A5;" class="fas fa-circle-user fa-4x my-4"></i>

                                <div class="form-outline mb-4" >
                                    <input style="background-color:#D4C0A5;" type="email" id="typeEmail" class="form-control form-control-lg" name="login_email" required/>
                                    <label class="form-label" for="typeEmail">Email</label>
                                </div>

                                <div class="form-outline mb-5">
                                    <input style="background-color:#D4C0A5;" type="password" id="typePassword" class="form-control form-control-lg" name="login_contraseña" required/>
                                    <label class="form-label" for="typePassword">Contraseña</label>
                                </div>

                                <button style="background-color:#D4C0A5;" class="btn btn-rounded gradient-custom px-5" type="submit">Ingresar</button>
                            </div>

                            <div>
                                <p style="color:#D4C0A5;" class="mb-0">¿No tenes cuenta? <a href="Registro.php" class="text-body fw-bold">Registrate</a></p>
                                <p style="color:#D4C0A5;" class="mb-0">¿Olvidaste tu contraseña? <a href="recuperar_contraseña.php" class="text-body fw-bold">Recuperar contraseña</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>

</body>
</html>