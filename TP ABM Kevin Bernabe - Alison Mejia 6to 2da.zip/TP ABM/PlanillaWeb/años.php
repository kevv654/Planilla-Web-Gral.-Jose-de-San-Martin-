<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
    rel="stylesheet"
    />

    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">
    
    <title>Gral. Jose de San Martin</title>

</head>
<body  style="background-color: #0F2D47;">
    <nav class="navbar navbar-expand-lg" style="background-color: #307AB4;">
        <div class="container-fluid d-flex justify-content-between">
            <img src="imagenes\logo.png" style="height: 150px; margin-left: 50px;">

            <div class="text-center">
                <h1 style="color: #D4C0A5;"><strong><em>"General Jose De San Martin"</strong></em></h1>
                <h2 style="color: #D4C0A5;"><strong><em>Escuela Tecnica Nº 32 D.E. 14</strong></em></h2>
            </div>

            <button
            class="navbar-toggler"
            type="button"
            data-mdb-toggle="collapse"
            data-mdb-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
            >
                <i class="fas fa-bars"></i>
            </button>

            <div class="d-flex align-items-center">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <div class="d-flex align-items-center">
                               
                                <?php   
                                session_start();
                                if(empty($_SESSION["email"])){
                                    echo '<div style="margin-right: 50px;" class="text-center">
                                            Error al conectar.
                                        </div>';
                                }else{
                                    $nombreUsuario  = $_SESSION["nombre"];
                                    echo '<div class="d-flex align-items-center">
                                            <div class="dropdown me-3">
                                                <a
                                                    class="dropdown-toggle d-flex align-items-center hidden-arrow user-dropdown nav-link"
                                                    href="#"
                                                    id="navbarDropdownMenuAvatar"
                                                    role="button"
                                                    data-mdb-toggle="dropdown"
                                                    aria-expanded="false"
                                                    title="Presione para ver opciones"
                                                >
                                                    <i style="color: #D4C0A5;" class="fas fa-circle-user fa-5x"></i><h1 class="user-name me-3" style="color: #D4C0A5;">'.$nombreUsuario .'</h1><i class="fas fa-caret-down fa-1x" style="color: #D4C0A5;"></i>
                                                </a>
                                            
                                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                                                    <li><h6 class="dropdown-item">¡Hola '.  $_SESSION["nombre"] .' '. $_SESSION["apellido"] .'!</h6></li>
                                                    <li><a class="dropdown-item" href="perfil.php">Mi perfil</a></li>
                                                    <li><hr class="dropdown-divider"/></li>
                                                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesion</a></li>
                                                </ul>
                                            </div>
                                        </div>';
                                }
                                ?>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
      
    <br>
      
    <div style="text-align: center;">
        <table class="table text-center" style="width: auto; display: inline-block;">
            <thead>
                <tr class="table-dark">
                    <th scope="row">Años</th>
                </tr>
            </thead>

            <tbody style="background-color: #D4C0A5;">
                <tr class="table">
                    <th scope="row"><a href="divisiones.php?anio=1" class="btn btn-dark">1er Año</a></th>
                </tr>
                <tr class="table">
                    <th scope="row"><a href="divisiones.php?anio=2" class="btn btn-dark">2do Año</a></th>
                </tr>
                <tr class="table">
                    <th scope="row"><a href="divisiones.php?anio=3" class="btn btn-dark">3er Año</a></th>
                </tr>
                <tr class="table">
                    <th scope="row"><a href="divisiones.php?anio=4" class="btn btn-dark">4to Año</a></th>
                </tr>
                <tr class="table">
                    <th scope="row"><a href="divisiones.php?anio=5" class="btn btn-dark">5to Año</a></th>
                </tr>
                <tr class="table">
                    <th scope="row"><a href="divisiones.php?anio=6" class="btn btn-dark">6to Año</a></th>
                </tr>
            </tbody>
        </table>
    </div>

    <?php
    echo '<div class="modal fade" id="miModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="miModalLabel">¡Bienvenido/a!</h5>
                </div>

                <div class="modal-body">';
                    
                    if($_SESSION['id_rol'] === 1){
                        echo '<p>Bienvenido a nuestro sistema <b>'. $nombreUsuario .'</b>. Su rol es de <b>Admnistrador</b>.</p>
                        <p>Dado a su rol, nuestro sistema le permitira gestionar una planilla de alumnos pertenecientes a los <b>años y divisiones</b> que veras a continuacion. Tambien dentro de las tablas, podras <b>editar los datos</b> que se presentan dentro de la tabla, podras <b>eliminarlos</b> de la tabla, <b>agregar mas alumnos</b> a la tabla, y tambien podras <b>asignar notas</b> a los aalumnos que desees buscando en las modificaciones de cada alumno.</p>
                        <p>Para ingresar a esta planilla, solo debes seleccionar el año y division y se generara una planilla en la que veras todos los datos de los alumnos pertenecientes a dicho curso.</p>
                        <p>Tambien podras <b>Administrar a los usuarios que se hayan registrado en nuestro sistema</b>. Para mas informacion ingrese a su perfil y presione el boton de <b>"Administrar Usuarios"</b>.</p>
                        <p>Siente a gusto con la pagina web y en caso de contar con problemas, ¡no olvides que puedes contactarnos!</p>
                        <p>----------------------------------------------------------------------</p>
                        <p>Si ha habido algun cambio en su rol, es posible que algún <b>Administrador</b> haya decidido cambiar su rol. Si eso presenta algún problema dado a su rango escolar, le sugerimos que se ponga en contacto con algún <b>superior, administrador o figura</b> del establecimiento para solucionar el problema.</p>
                        <p>- Equipo de conduccion.<p>'; 
                    }

                    if($_SESSION['id_rol'] === 2){
                        echo '<p>Bienvenido a nuestro sistema. Su rol es de <b>Profesor / Preceptor</b>.</p>
                        <p>Dado a su rol, nuestro sistema le permitira gestionar una planilla de alumnos pertenecientes a los <b>años y divisiones</b> que veras a continuacion. Tambien dentro de las tablas, podras <b>editar los datos</b> que se presentan dentro de la tabla, podras <b>eliminarlos</b> de la tabla, <b>agregar mas alumnos</b> a la tabla, y tambien podras <b>asignar notas</b> a los alumnos que desees buscando en las modificaciones de cada alumno.</p>
                        <p>Para ingresar a esta planilla, solo debes seleccionar el año y division y se generara una planilla en la que veras todos los datos de los alumnos pertenecientes a dicho curso.</p>
                        <p>Siente a gusto con la pagina web y en caso de contar con problemas, ¡no olvides que puedes contactarnos!</p>
                        <p>----------------------------------------------------------------------</p>
                        <p>Si ha habido algun cambio en su rol, es posible que algún <b>Administrador</b> haya decidido cambiar su rol. Si eso presenta algún problema dado a su rango escolar, le sugerimos que se ponga en contacto con algún <b>superior, administrador o figura</b> del establecimiento para solucionar el problema.</p>
                        <p>Tambien puede solicitar un <b>Aumento de Rol</b> ingresando a su perfil y presionando el boton <b class="text-success">Solicitar Aumento de Rol</b>.</p>
                        <p>- Equipo de conduccion.<p>'; 
                    }

                    if($_SESSION['id_rol'] === 3){
                        echo '<p>Bienvenido a nuestro sistema. Su rol es de <b>Alumno / Usuario Regular</b>.</p>
                        <p>Dado a su rol, nuestro sistema unicamente le permitirá <b>Ver sus notas personales</b> como alumno.</p>
                        <p>Para ingresar a esta planilla, solo debes seleccionar el año y division y se generara una planilla en la que veras todos los datos de los alumnos pertenecientes a dicho curso. Unicamente busque el curso al que pertenece y corrobore sus notas.</p>
                        <p>Siente a gusto con la pagina web y en caso de contar con problemas, ¡no olvides que puedes contactarnos!</p>
                        <p>----------------------------------------------------------------------</p>
                        <p>Si ha habido algun cambio en su rol, es posible que algún <b>Administrador</b> haya decidido cambiar su rol. Si eso presenta algún problema dado a su rango escolar, le sugerimos que se ponga en contacto con algún <b>superior, administrador o figura</b> del establecimiento para solucionar el problema.</p>
                        <p>Tambien puede solicitar un <b>Aumento de Rol</b> ingresando a su perfil y presionando el boton <b class="text-success">Solicitar Aumento de Rol</b>.</p>
                        <p>- Equipo de conduccion.<p>'; 
                    }
                    
                echo '</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>';

    if($_SESSION['cuenta'] === 1){
        echo '<script>
                setTimeout(function() {
                var modal = new mdb.Modal(document.getElementById("miModal"));
                modal.show();
                }, 1000);
            </script>';
        $_SESSION['cuenta'] = 2;
    }

    ?>

    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
</body>
</html>