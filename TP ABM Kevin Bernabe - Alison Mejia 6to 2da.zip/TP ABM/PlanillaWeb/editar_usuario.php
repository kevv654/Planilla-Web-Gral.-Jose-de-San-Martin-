<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
    rel="stylesheet"
    />

    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">
    
    <title>Gral. Jose de San Martin</title>

</head>
<body  style="background-color: #0F2D47;">
    <nav class="navbar navbar-expand-lg" style="background-color: #307AB4;">
        <div class="container-fluid d-flex justify-content-between">
            <img src="imagenes\logo.png" style="height: 150px; margin-left: 50px;">

            <div class="text-center">
                <h1 style="color: #D4C0A5;"><strong><em>"General Jose De San Martin"</strong></em></h1>
                <h2 style="color: #D4C0A5;"><strong><em>Escuela Tecnica Nº 32 D.E. 14</strong></em></h2>
            </div>

            <button
            class="navbar-toggler"
            type="button"
            data-mdb-toggle="collapse"
            data-mdb-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
            >
                <i class="fas fa-bars"></i>
            </button>

            <div class="d-flex align-items-center">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <div class="d-flex align-items-center">
                                
                                <?php   
                                session_start();
                                if(empty($_SESSION["email"])){
                                    echo '<div style="margin-right: 50px;" class="text-center">
                                            Error al conectar.
                                        </div>';
                                }else{
                                    $nombreUsuario  = $_SESSION["nombre"];
                                    echo '<div class="d-flex align-items-center">
                                            <div class="dropdown me-3">
                                                <a
                                                    class="dropdown-toggle d-flex align-items-center hidden-arrow user-dropdown nav-link"
                                                    href="#"
                                                    id="navbarDropdownMenuAvatar"
                                                    role="button"
                                                    data-mdb-toggle="dropdown"
                                                    aria-expanded="false"
                                                    title="Presione para ver opciones"
                                                >
                                                    <i style="color: #D4C0A5;" class="fas fa-circle-user fa-5x"></i><h1 class="user-name me-3" style="color: #D4C0A5;">'.$nombreUsuario .'</h1><i class="fas fa-caret-down fa-1x" style="color: #D4C0A5;"></i>
                                                </a>
                                            
                                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                                                    <li><h6 class="dropdown-item">¡Hola '.  $_SESSION["nombre"] .' '. $_SESSION["apellido"] .'!</h6></li>
                                                    <li><a class="dropdown-item" href="perfil.php">Mi perfil</a></li>
                                                    <li><hr class="dropdown-divider"/></li>
                                                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesion</a></li>
                                                </ul>
                                            </div>
                                        </div>';
                                }

                                ?>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <br>

    <div style="width:110px; margin-left:30px;">
        <a href="#" onclick="history.back(); return false;"><i style="color:#D4C0A5; float:left;" class="fas fa-angles-left fa-2x"></i><h3 style="color:#D4C0A5;" >Volver</h3></a>
    </div>

    <?php

        if(isset($_GET['id'])) {
            $usuario_id = $_GET['id'];

            include("conexion.php");

            if ($conexion->connect_error) {
                die("Error de conexión: " . $conexion->connect_error);
            }

            $query = "SELECT * FROM usuario WHERE id = " . $usuario_id;
            $result = $conexion->query($query);
       
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();

                if($row['id_rol'] === '1'){
                    $rol = 'Administrador';
    
                } 
                if($row['id_rol'] === '2'){
                    $rol = 'Profesor / Preceptor';
    
                }
                if($row['id_rol'] === '3'){
                    $rol = 'Alumno / Usuario Regular';
    
                }

                echo '<div style="text-align: center;">
                        <div class="card my-4" style="width: 600px; background-color: #307AB4; display: inline-block;">
                            <div class="card-body">
                    
                                <h1 class="card-title" style="color:#D4C0A5;">Editar Usuario - ID: ' . $usuario_id . ' - '. $row['nombre'] .' '. $row['apellido'] .'</h1>
                    
                                <form method="POST" action="#">
                                    <input type="hidden" name="usuario_id" value="' . $usuario_id . '">

                                    <div class="row mb-4">
                                        <div class="col">
                                            <h3 class="me-3" style="color:#D4C0A5;">Rol:</h3>
                                            <select style="background-color:#D4C0A5;" id="rolSelect" class="form-select" name="rol" required>
                                                <option value="'.$row['id_rol'].'">'.$rol.'</option>
                                                <option value="1">Administrador</option>
                                                <option value="2">Profesor / Preceptor</option>
                                                <option value="3">Alumno / Usuario Regular</option>
                                            </select>                                            
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col">
                                            <div class="form-outline">
                                                <input style="background-color:#D4C0A5;" type="tel" class="form-control form-control-lg" name="telefono" value="' . $row['telefono'] . '" required>
                                                <label class="form-label" for="telefono">Teléfono:</label>
                                            </div>

                                        </div>
                                    </div>

                                    <button type="submit" class="btn" style="background-color:#D4C0A5;">Guardar cambios</button>
                                </form>
                            </div>
                        </div>
                    </div>';
            } else {
                echo 'No se encontró el Usuario con ID: ' . $id_usuario;
            }

            $conexion->close();
        } else {
            echo 'ID de Usuario no proporcionado.';
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_usuario = htmlspecialchars($_POST['usuario_id']);
            $telefono = htmlspecialchars($_POST['telefono']);
            $id_rol = htmlspecialchars($_POST['rol']);
        
            include("conexion.php");
        
            if ($conexion->connect_error) {
                die("Error de conexión: " . $conexion->connect_error);
            }
        
            $stmt = $conexion->prepare("SELECT telefono, id_rol FROM usuario WHERE id = ?");
            $stmt->bind_param("i", $id_usuario);
            $stmt->execute();
            $stmt->bind_result($telefono_actual, $id_rol_actual);
            $stmt->fetch();
            $stmt->close();
        
            if ($id_rol === '1') {
                $rol = 'Administrador';
            } elseif ($id_rol === '2') {
                $rol = 'Profesor / Preceptor';
            } elseif ($id_rol === '3') {
                $rol = 'Alumno / Usuario Regular';
            }
        
            if ($telefono != $telefono_actual || $id_rol != $id_rol_actual) {
                $remitente_id = $_SESSION['ID'];
                $destinatario_id = $id_usuario;
                $titulo = 'Se han realizado cambios en su perfil por parte de un Administrador';
                $contenido = 'Cambios Realizados:
                            <ul class="list-unstyled">';
        
                if ($telefono != $telefono_actual) {
                    $contenido .= '<li class="mb-1"><i class="fas fa-check-circle me-2 text-success"></i>Su teléfono ha sido actualizado a <b>' . $telefono . '</b>.</li>';
                }
        
                if ($id_rol != $id_rol_actual) {
                    $contenido .= '<li class="mb-1"><i class="fas fa-check-circle me-2 text-success"></i>Su rol ha sido cambiado a <b>' . $rol . '</b>.</li>';
                }
        
                $contenido .= '</ul>';
        
                $stmt = $conexion->prepare("INSERT INTO mensajes (remitente_id, destinatario_id, titulo, contenido) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("iiss", $remitente_id, $destinatario_id, $titulo, $contenido);
                $stmt->execute();
                $stmt->close();
            }
        
            $stmt = $conexion->prepare("UPDATE usuario SET telefono=?, id_rol=? WHERE id=?");
            $stmt->bind_param("ssi", $telefono, $id_rol, $id_usuario);
        
            if ($stmt->execute()) {
                echo '<div class="modal top fade" id="miModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
                        <div class="modal-dialog  ">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">¡Datos Editados con Éxito!</h5>
                                </div>
                                <div class="modal-body">Los cambios se han guardado correctamente.</div>
                                <div class="modal-footer">
                                    <a href="perfil.php" class="btn btn-primary">Volver</a>
                                </div>
                            </div>
                        </div>
                    </div>';
            } else {
                echo "Error al guardar los cambios: " . $stmt->error;
            }
        
            $stmt->close();
            $conexion->close();
        }
    ?>

    <script>
        setTimeout(function() {
        var modal = new mdb.Modal(document.getElementById('miModal'));
        modal.show();
        }, 100);
    </script>
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
</body>
</html>