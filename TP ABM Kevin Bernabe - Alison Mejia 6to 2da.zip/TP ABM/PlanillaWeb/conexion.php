<?php 
    $conexion = new mysqli("localhost","root","","colegio");
    mysqli_set_charset($conexion, "utf8mb4");
?>