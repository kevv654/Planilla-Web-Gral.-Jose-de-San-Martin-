<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
    rel="stylesheet"
    />

    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">

    <title>Vicson</title>
</head>


<body style="background-color:#0F2D47;">
    <form action="procesos.php" class="intro" method="POST">
        <div class="container my-4">
            <div class="row justify-content-center">
                <div class="col-12 col-md-8 col-lg-8 col-xl-8">
                    <div class="card" style="border-radius: 1rem; background-color:#307AB4;">
                        <div class="card-body p-5 text-center" >

                            <div class="my-md-5">

                                <div class="position-absolute top-0 start-0" style="width:120px; margin-left: 20px; margin-top: 20px;">
                                    <a href="#" onclick="history.back(); return false;"><i style="color:#D4C0A5; float:left;" class="fas fa-angles-left fa-2x"></i><h3 style="color:#D4C0A5;" >Volver</h3></a>
                                </div>

                                <h1 class="fw-bold mb-2" style="color:#D4C0A5;">Registro de Cuenta</h1>                                     

                                <div class="row mb-3">
                                    <div class="col">
                                        <div class="form-outline">
                                            <input style="background-color:#D4C0A5;" type="text" id="nombre" class="form-control form-control-lg" name="registro_nombre" required/>
                                            <label class="form-label" for="nombre">Nombre(s)</label>
                                        </div>
                                    </div>

                                    <div class="col">
                                        <div class="form-outline">
                                            <input style="background-color:#D4C0A5" type="text" id="apellido" class="form-control form-control-lg" name="registro_apellido" required/>
                                            <label class="form-label" for="apellido">Apellido(s)</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col">
                                        <div class="form-outline datepicker" style="background-color:#D4C0A5">
                                            <input style="background-color:#D4C0A5"
                                                type="date"
                                                class="form-control form-control-lg"
                                                id="fnacimiento"
                                                name="registro_fnacimiento"
                                                required
                                            />
                                            <label for="fnacimiento" class="form-label">Fecha de Nacimiento</label>
                                        </div>
                                    </div>

                                    <div class="col">
                                        <h5 class="mb-1 pb-1" style="color:#D4C0A5">Genero: </h5>

                                        <div class="form-check form-check-inline">
                                            <input
                                                class="form-check-input"
                                                type="radio"
                                                name="registro_genero"
                                                id="femenino"
                                                value="Mujer"
                                                required
                                            />
                                            <label class="form-check-label" for="femenino" style="color:#D4C0A5">Femenino</label>
                                        </div>

                                        <div class="form-check form-check-inline">
                                            <input  
                                                class="form-check-input"
                                                type="radio"
                                                name="registro_genero"
                                                id="Masculino"
                                                value="Hombre"
                                                required
                                            />
                                            <label class="form-check-label" for="Masculino" style="color:#D4C0A5">Masculino</label>
                                        </div>

                                        <div class="form-check form-check-inline">
                                            <input 
                                                class="form-check-input"
                                                type="radio"
                                                name="registro_genero"
                                                id="Otro"
                                                value="Otro"
                                                required
                                            />
                                            <label class="form-check-label" for="Otro" style="color:#D4C0A5">Otro</label>
                                        </div>

                                    </div>

                                </div>

                                <div class="row mb-3">
                                    <div class="col">
                                        <div class="form-outline">
                                            <input style="background-color:#D4C0A5" type="email" id="email" class="form-control form-control-lg" name="registro_email" required/>
                                            <label class="form-label" for="email">Email</label>
                                        </div>
                                    </div>

                                    <div class="col">
                                        <div class="form-outline">
                                            <input style="background-color:#D4C0A5" type="number" id="telefono" class="form-control form-control-lg" name="registro_telefono" required/>
                                            <label class="form-label" for="telefono">Telefono</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col">
                                        <div class="form-outline">
                                            <input style="background-color:#D4C0A5" type="password" id="contraseña"  minlength="8" pattern="^(?=.*\d)(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$" class="form-control form-control-lg" name="registro_contraseña" required/>
                                            <label class="form-label" for="contraseña">Contraseña(8 carac./!@#$%^&*/Num.)</label>
                                        </div>
                                    </div>

                                    <div class="col">
                                        <div class="form-outline">
                                            <input style="background-color:#D4C0A5" type="password" id="confirmacion_contraseña" class="form-control form-control-lg" name="registro_confirmacion_contraseña" required/>
                                            <label class="form-label" for="confirmacion_contraseña">Confirmar Contraseña</label>
                                        </div>
                                    </div>
                                </div>
                                <button style="background-color:#D4C0A5" class="btn btn-lg btn-rounded gradient-custom text-body px-5" type="submit">Registrar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="modal top fade" id="modalAclaracion" tabindex="-1" aria-labelledby="a" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="a">Registrar Cuenta</h5>
                    <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Mediante este formulario podra registrarse dentro de nuestro sistema de planilla web.</p>
                    <p><b>Importante.</b> Le recomendamos que al registrarse, siendo <b>Alumno/a</b>, use credenciales reales relacionadas a su <b>Nombre, Apellido, Email, etc.</b>, para que asi pueda ver sus datos reales en la planilla y por lo tanto sus respectivas notas.</p>
                    <p><b>Si utiliza datos no relacionados a usted, podria ser reportado y su cuenta deshabilitada.</b></p>
                    <p>¡Muchas Gracias!</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        setTimeout(function() {
        var modal = new mdb.Modal(document.getElementById("modalAclaracion"));
        modal.show();
        }, 300);
    </script>

    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>

</body>
</html>