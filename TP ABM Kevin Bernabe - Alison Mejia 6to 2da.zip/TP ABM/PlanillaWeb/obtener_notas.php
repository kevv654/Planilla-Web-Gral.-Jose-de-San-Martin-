<?php
session_start();
$alumnoId = $_GET['alumno_id'];

include("conexion.php");

$sql = "SELECT * FROM notas WHERE alumno_id = $alumnoId";
$result = $conexion->query($sql);

if ($result->num_rows > 0) {
    echo '<table class="table table-striped">
            <thead>
                <tr class="table-dark">
                    <th scope="row">Asignatura</th>
                    <th scope="row">Nota</th>
                    <th scope="row">Observaciones</th>';
        if($_SESSION['id_rol'] === 1 or $_SESSION['id_rol'] === 2){
            echo '<th scope="row">Modificaciones</th>';
        }
        echo '</tr>
        </thead>
        <tbody style="background-color: #D4C0A5;">';
    while ($row = $result->fetch_assoc()) {
        echo '<tr class="table">
                <td style="color: black;">' . $row["asignatura"] . '</td>
                <td style="color: black;">' . $row["nota"] . '</td>
                <td style="color: black;">' . $row["observaciones"] . '</td>';
                
        if($_SESSION['id_rol'] === 1 or $_SESSION['id_rol'] === 2){
            echo '<td>
                <a href="eliminar_nota.php?id=' . $row["id"] . '" class="btn btn-danger">Eliminar</a>
            </td>';
        }

        echo '</tr>';
    }
    echo '</tbody></table>';
} else {
    echo '<p>No se encontraron notas para este alumno.</p>';
}
?>
