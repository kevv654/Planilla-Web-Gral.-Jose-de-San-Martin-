<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
    rel="stylesheet"
    />

    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">
    
    <title>Gral. Jose de San Martin</title>

</head>
<body  style="background-color: #0F2D47;">
    <nav class="navbar navbar-expand-lg" style="background-color: #307AB4;">
        <div class="container-fluid d-flex justify-content-between">
            <img src="imagenes\logo.png" style="height: 150px; margin-left: 50px;">

            <div class="text-center">
                <h1 style="color: #D4C0A5;"><strong><em>"General Jose De San Martin"</strong></em></h1>
                <h2 style="color: #D4C0A5;"><strong><em>Escuela Tecnica Nº 32 D.E. 14</strong></em></h2>
            </div>

            <button
            class="navbar-toggler"
            type="button"
            data-mdb-toggle="collapse"
            data-mdb-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
            >
                <i class="fas fa-bars"></i>
            </button>

            <div class="d-flex align-items-center">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <div class="d-flex align-items-center">
                                
                                <?php   
                                session_start();
                                if(empty($_SESSION["email"])){
                                    echo '<div style="margin-right: 50px;" class="text-center">
                                            Error al conectar.
                                        </div>';
                                }else{
                                    $nombreUsuario  = $_SESSION["nombre"];
                                    echo '<div class="d-flex align-items-center">
                                            <div class="dropdown me-3">
                                                <a
                                                    class="dropdown-toggle d-flex align-items-center hidden-arrow user-dropdown nav-link"
                                                    href="#"
                                                    id="navbarDropdownMenuAvatar"
                                                    role="button"
                                                    data-mdb-toggle="dropdown"
                                                    aria-expanded="false"
                                                    title="Presione para ver opciones"
                                                >
                                                    <i style="color: #D4C0A5;" class="fas fa-circle-user fa-5x"></i><h1 class="user-name me-3" style="color: #D4C0A5;">'.$nombreUsuario .'</h1><i class="fas fa-caret-down fa-1x" style="color: #D4C0A5;"></i>
                                                </a>
                                            
                                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                                                    <li><h6 class="dropdown-item">¡Hola '.  $_SESSION["nombre"] .' '. $_SESSION["apellido"] .'!</h6></li>
                                                    <li><a class="dropdown-item" href="perfil.php">Mi perfil</a></li>
                                                    <li><hr class="dropdown-divider"/></li>
                                                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesion</a></li>
                                                </ul>
                                            </div>
                                        </div>';
                                }

                                ?>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>    

    <br>

    <div style="width:110px; margin-left:30px;">
        <a href="#" onclick="history.back(); return false;"><i style="color:#D4C0A5; float:left;" class="fas fa-angles-left fa-2x"></i><h3 style="color:#D4C0A5;" >Volver</h3></a>
    </div>

    <?php
        if(isset($_GET['id'])) {
            $usuario_id = $_GET['id'];

            include("conexion.php");

            
            if ($conexion->connect_error) {
                die("Error de conexión: " . $conexion->connect_error);
            }

            $query = "SELECT * FROM usuario WHERE id = " . $usuario_id;
            $result = $conexion->query($query);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();

                echo '<div style="text-align: center;">
                        <div class="card" style="width: 500px; display: inline-block;">
                            <div class="card-body">
                                <h1 class="card-title">Eliminar Usuario - ID: ' . $usuario_id . '</h1>

                                <p class="card-text">¿Estás seguro de que deseas eliminar a ' . $row['nombre'] . ' ' . $row['apellido'] . ' de Email '. $row['email'] .'?</p>
                
                                <form method="POST" action="#">
                                    <input type="hidden" name="usuario_id" value="' . $usuario_id . '">
                                    <button type="submit" class="btn btn-danger">Eliminar</button>
                                </form>
                            </div>
                        </div>
                    </div>';
            } else {
                echo 'No se encontró el Usuario con ID: ' . $usuario_id;
            }

            
            $conexion->close();
        } else {
            echo 'ID de Usuario no proporcionado.';
        }
    ?>
    <?php
        if($_SERVER['REQUEST_METHOD'] === 'POST') {
            $usuario_id = $_POST['usuario_id'];
        
            include("conexion.php");
        
            if ($conexion->connect_error) {
                die("Error de conexión: " . $conexion->connect_error);
            }
        
            $query = "DELETE FROM usuario WHERE id=$usuario_id";
            if ($conexion->query($query) === TRUE) {
                echo '<div class="modal top fade" id="miModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
                        <div class="modal-dialog  ">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">¡Usuario Eliminado!</h5>
                                </div>
                                <div class="modal-body">
                                    El usuario ha sido eliminado. 
                                </div>
                                <div class="modal-footer">
                                    <a class="btn btn-danger" href="planilla.php">Volver</a>
                                </div>
                            </div>
                        </div>
                    </div>';
            } else {
                echo "Error al eliminar el Usuario: " . $conexion->error;
            }
        
            $conexion->close();
        }
    ?>

    <script>
        setTimeout(function() {
        var modal = new mdb.Modal(document.getElementById('miModal'));
        modal.show();
        }, 100);
    </script>
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
</body>
</html>