<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
    rel="stylesheet"
    />

    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">
    
    <title>Gral. Jose de San Martin</title>

    <style>
        .testimonial-card .card-up {
            height: 120px;
            overflow: hidden;
            border-top-left-radius: .25rem;
            border-top-right-radius: .25rem;
        }

        .aqua-gradient {
            background: linear-gradient(40deg, red, yellow, blue) !important;
        }

        .testimonial-card .avatar {
            width: 120px;
            margin-top: -60px;
            overflow: hidden;
            border: 5px solid #fff;
            border-radius: 50%;
            background-color: white;
        }

    </style>

</head>
<body class="bg-image" style="background-image: url('https://lh3.googleusercontent.com/p/AF1QipP1u3UM-apbchQM_W4BoRy4Ca3_IMm72zYeAR0o=s1360-w1360-h1020'); height: 100vh">

    <?php
    session_start();        
    if (isset($_SESSION["email"])) {

        $email = $_SESSION["email"];

        include("conexion.php");
                                                
        $consulta_sql = "SELECT * FROM usuario WHERE email = '$email'";
        $resultado = $conexion->query($consulta_sql);

        if ($resultado->num_rows > 0) {
            $row = $resultado->fetch_assoc();
            if($row['id_rol'] === '1'){
                $rol = 'Administrador';

            } 
            if($row['id_rol'] === '2'){
                $rol = 'Profesor / Preceptor';

            }
            if($row['id_rol'] === '3'){
                $rol = 'Alumno / Usuario Regular';

            }

            if (isset($_GET["id"])) {
                $usuario_id = $_GET["id"];
                $query = "DELETE FROM mensajes WHERE destinatario_id=$usuario_id";  
                
                if ($conexion->query($query) === TRUE) {

                } else {
                    echo "Error: " . $conexion->error;
                }
            }

            $destinatario_id = $_SESSION['ID'];

            // Consulta SQL para seleccionar mensajes con el destinatario_id específico
            $sql = "SELECT * FROM mensajes WHERE destinatario_id = $destinatario_id";

            $result = $conexion->query($sql);

            if ($result) {
                $numeroMensajes = $result->num_rows;
            } else{
                $numeroMensajes = 0;
            }

            

            echo '<div class="container my-5">
                    <div class="row justify-content-center">
                        <div class="col-md-8">
                            <div class="card testimonial-card mt-1 mb-1">
                                <div class="card-up aqua-gradient">
                                    <div style="width:110px; margin-left:10px; margin-top:10px;">
                                        <a style="color:black;" href="años.php"><i style="float:left;" class="fas fa-angles-left fa-2x"></i><h3>Volver</h3></a>
                                    </div>
                                </div>
                                <div class="avatar mx-auto white">
                                    <i style="color:black;" class="fas fa-circle-user fa-7x"></i>
                                </div>
                                <div class="card-body text-center">
                                    <h4 class="card-title font-weight-bold">'.$row['nombre'].' '.$row['apellido'].'</h4>
                                    <h5 class="card-title font-weight-bold">('.$rol.')</h5>
                                    <h6 class="card-title font-weight-bold"><i class="fas fa-envelope"></i> '.$row['email'].'</h6>
                                    
                                    <p><i class="fas fa-phone"></i> Numero de Telefono: '.$row['telefono'].'</p>

                                    <a href="cerrar_sesion.php" class="btn btn-danger">Cerrar Sesion</a>
                                    <button type="button" class="btn btn-primary me-1" data-mdb-toggle="modal" data-mdb-target="#ModalEditar">Editar Datos Personales</button>
                                    <button type="button" class="btn btn-warning me-1" data-mdb-toggle="modal" data-mdb-target="#modalMensajes">Mensajes <span class="badge badge-pill bg-danger">'. $numeroMensajes .'</span></button>';
                                    
                                    if($row['id_rol'] === '1'){
                                        echo '<button type="button" class="btn btn-dark" data-mdb-toggle="modal" data-mdb-target="#ModalUsuarios">Administrar Usuarios</button>';

                                    } 

                                    if($row['id_rol'] === '2' or $row['id_rol'] === '3'){
                                        echo '<button type="button" class="btn btn-success" data-mdb-toggle="modal" data-mdb-target="#modalAumentoRol">Solicitar aumento de rol</button>';

                                    }

                            echo '</div>
                            </div>
                        </div>
                    </div>
                </div>';
                                                    
        } else {
            echo "No se encontraron registros del usuario.";
        }
        $conexion->close();
    } else {
        echo "No se ha iniciado sesión.";
    }
    ?>
    
    <!-- Modal de Edicion -->
    <div class="modal top fade" id="ModalEditar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
        <div class="modal-dialog  ">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Datos Personales</h5>
                    <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Haz solicitado la Edicion de tus Datos personales. Accediendo podras cambiar aspectos importantes, tales como <b>tu informacion de contacto, correo electronico, contraseña</b>, etc.</p>
                    <p>Antes de ello, por favor, ingrese su contraseña para poder acceder al editor.</p>
                    <form action="procesos.php" method="POST">
                        <div class="form-outline mb-3">
                            <input type="password" id="typePassword" class="form-control form-control-lg" name="contraseña" required/>
                            <label class="form-label" for="typePassword">Contraseña</label>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">Enviar</button>
                    </form>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Usuarios -->
    <div class="modal top fade" id="ModalUsuarios" tabindex="-1" aria-labelledby="Usuarios" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="Usuarios">Editar Usuarios</h5>
                    <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="max-height: 60vh; overflow-y: auto;">
                    <p>Mediante esta seccion, podrá gestionar a los usuarios que se encuentren registrados dentro de nuestra pagina web, editando algunos de sus datos, contactos, podra <b>asignar roles</b> entre <b>Alumno, Profesor / Preceptor o Administrador</b>, y demas modificaciones. Actue con responsabilidad.</p>
                    <?php
                    include('conexion.php');
                    $sessionEmail = $_SESSION["email"];
                    $consulta_usuarios = "SELECT * FROM usuario WHERE email <> '$sessionEmail' ORDER BY id_rol ASC";;
                    $resultado_usuarios = $conexion->query($consulta_usuarios);
                    if ($resultado_usuarios->num_rows > 0) {
                        
                        
                        echo '<table class="table table-bordered table-striped">
                                <thead>
                                    <tr class="table-dark">
                                        <th scope="row">ID de Usuario</th>
                                        <th scope="row">Nombre</th>
                                        <th scope="row">Apellido</th>
                                        <th scope="row">Fecha de Nacimiento</th>
                                        <th scope="row">Email</th>
                                        <th scope="row">Teléfono</th>
                                        <th scope="row">Rol</th>
                                        <th scope="row">Modificaciones</th>
                                    </tr>
                                </thead>
                        <tbody style="background-color: #D4C0A5;">';

                        while ($filas = $resultado_usuarios->fetch_assoc()) {
                            if($filas['id_rol'] === '1'){
                                $rol_usuario = 'Administrador';
                
                            } 
                            if($filas['id_rol'] === '2'){
                                $rol_usuario = 'Profesor / Preceptor';
                
                            }
                            if($filas['id_rol'] === '3'){
                                $rol_usuario = 'Alumno / Usuario Regular';
                
                            }
                            echo '<tr class="table">
                                    <td style="color: black;">' . $filas["ID"] . '</td>
                                    <td style="color: black;">' . $filas["nombre"] . '</td>
                                    <td style="color: black;">' . $filas["apellido"] . '</td>
                                    <td style="color: black;">' . $filas["fnacimiento"] . '</td>
                                    <td style="color: black;">' . $filas["email"] . '</td>
                                    <td style="color: black;">' . $filas["telefono"] . '</td>
                                    <td style="color: black;">' . $rol_usuario . '</td>
                                    <td>
                                        <a href="editar_usuario.php?id=' . $filas["ID"] . '" class="btn btn-primary">Editar</a>
                                        <br><br>
                                        <a href="eliminar_usuario.php?id=' . $filas["ID"] . '" class="btn btn-danger">Eliminar</a>
                                        
                                    </td>
                                </tr>';
                        }

                        echo '</tbody></table>';

                                                                
                    } else {
                        echo "No se encontraron registros de usuarios.";
                    }
                    
                    ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Cambio de Rol -->
    <div class="modal top fade" id="modalAumentoRol" tabindex="-1" aria-labelledby="a" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="a">Solicitar Aumento o cambio de Rol</h5>
                    <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Haz solicitado <b>El Aumento o Cambio de ROL</b>.</p>
                    <p>Tenga en cuenta que quien decidira cambiar su rol seran los <b>Administradores</b> del sistema.</p>
                    <p>Mediante este medio, se le enviara un <b>Gmail</b> a alguno de los administradores del sistema, junto con sus datos personales y ellos decidiran si aceptar su solicitud o declinar.</p>
                    <p>Simplemente seleccione el Rol que solicitara y se enviara automaticamente un Mail a alguno de los Administradores.</p>
                    <p><b>¡Advertencia!</b> No haga perder el tiempo al personal, sea serio y responsable o podria haber consecuencias.</p>

                    <?php 
                        if($_SESSION['id_rol'] === 3){
                            echo '<a href="enviar_solicitud.php?rol=2" class="btn btn-success">Solicitar Rol Maestro / Preceptor</a>';
                        } 
                    ?>

                    <a href="enviar_solicitud.php?rol=1" class="btn btn-dark">Solicitar Rol Administrador</a>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Mensajes -->
    <div class="modal top fade" id="modalMensajes" tabindex="-1" aria-labelledby="mensajes" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="mensajes">Mensajes</h5>
                    <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="max-height: 60vh; overflow-y: auto;">
                    
                    <?php
                    include('conexion.php');

                    if (isset($_GET["id"])) {
                        $usuario_id = $_GET["id"];
                        $query = "DELETE FROM mensajes WHERE destinatario_id=$usuario_id";                                
                    }

                    $sesionID = $_SESSION["ID"];
                    $consulta_mensajes = "SELECT * FROM mensajes WHERE destinatario_id = $sesionID;";
                    $resultado_mensajes = $conexion->query($consulta_mensajes);
                    
                    if ($resultado_mensajes->num_rows > 0) {
                        while ($mensajes = $resultado_mensajes->fetch_assoc()) {
                            echo '<row>
                                    <div class="card border border-dark mb-3">
                                        <p class="card-header"><b>' . $mensajes['fecha_envio'] . '</b></p>
                                        <div class="card-body">
                                            <h5 class="card-title">' . $mensajes['titulo'] . '</h5>
                                            <p class="card-text">' . $mensajes['contenido'] . '</p>
                                        </div>
                                    </div>
                                </row>';

                        }
                                                                
                    } else {
                        echo "No tienes mensajes.";
                    }
                    
                    ?>

                </div>
                <div class="modal-footer">
                    <?php
                        echo '<a href="perfil.php?id=' . $_SESSION["ID"] . '" class="btn btn-danger">Eliminar Mensajes</a>';
                    ?>
                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>


    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
</body>
</html>