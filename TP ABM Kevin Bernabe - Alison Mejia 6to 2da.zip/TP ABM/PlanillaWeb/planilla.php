<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
    rel="stylesheet"
    />

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">
    
    <title>Gral. Jose de San Martin</title>

</head>

<body  style="background-color: #0F2D47;">
    <nav class="navbar navbar-expand-lg" style="background-color: #307AB4;">
        <div class="container-fluid d-flex justify-content-between">
            <img src="imagenes\logo.png" style="height: 150px; margin-left: 50px;">

            <div class="text-center">
                <h1 style="color: #D4C0A5;"><strong><em>"General Jose De San Martin"</strong></em></h1>
                <h2 style="color: #D4C0A5;"><strong><em>Escuela Tecnica Nº 32 D.E. 14</strong></em></h2>
            </div>

            <button
            class="navbar-toggler"
            type="button"
            data-mdb-toggle="collapse"
            data-mdb-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
            >
                <i class="fas fa-bars"></i>
            </button>

            <div class="d-flex align-items-center">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <div class="d-flex align-items-center">
                                
                                <?php   
                                session_start();
                                if(empty($_SESSION["email"])){
                                    echo '<div style="margin-right: 50px;" class="text-center">
                                            Error al conectar.
                                        </div>';
                                }else{
                                    $nombreUsuario  = $_SESSION["nombre"];
                                    echo '<div class="d-flex align-items-center">
                                            <div class="dropdown me-3">
                                                <a
                                                    class="dropdown-toggle d-flex align-items-center hidden-arrow user-dropdown nav-link"
                                                    href="#"
                                                    id="navbarDropdownMenuAvatar"
                                                    role="button"
                                                    data-mdb-toggle="dropdown"
                                                    aria-expanded="false"
                                                    title="Presione para ver opciones"
                                                >
                                                    <i style="color: #D4C0A5;" class="fas fa-circle-user fa-5x"></i><h1 class="user-name me-3" style="color: #D4C0A5;">'.$nombreUsuario .'</h1><i class="fas fa-caret-down fa-1x" style="color: #D4C0A5;"></i>
                                                </a>
                                            
                                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                                                    <li><h6 class="dropdown-item">¡Hola '.  $_SESSION["nombre"] .' '. $_SESSION["apellido"] .'!</h6></li>
                                                    <li><a class="dropdown-item" href="perfil.php">Mi perfil</a></li>
                                                    <li><hr class="dropdown-divider"/></li>
                                                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesion</a></li>
                                                </ul>
                                            </div>
                                        </div>';
                                }

                                if (isset($_GET['division'])) {
                                    $_SESSION['divisionSeleccionada'] = $_GET['division'];
                                }

                                if (isset($_SESSION['anioSeleccionado'])) {
                                    $anioSeleccionado = $_SESSION['anioSeleccionado'];
                                } else {
        
                                    $anioSeleccionado = "No se ha seleccionado ningún año.";
                                }
                                
                                if (isset($_SESSION['divisionSeleccionada'])) {
                                    $divisionSeleccionada = $_SESSION['divisionSeleccionada'];
                                } else {

                                    $divisionSeleccionada = "No se ha seleccionado ninguna división.";
                                }
                                ?>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <br>

    <div style="width:110px; margin-left:30px;">
        <a href="años.php"><i style="color:#D4C0A5; float:left;" class="fas fa-angles-left fa-2x"></i><h3 style="color:#D4C0A5;" >Volver</h3></a>
    </div>

    <div class="container">
        <?php
            include("conexion.php");

            echo '<div style="text-align: center;">
                    <h1 style="color:#D4C0A5; width: auto; height: auto;">Alumnos de ' .$anioSeleccionado.'º Año ' .$divisionSeleccionada.'º Division</h1>
                </div> 
            <br>';
        

            if ($conexion->connect_error) {
                die("Error de conexión: " . $conexion->connect_error);
            }


            $sql = "SELECT alumnos.id AS 'ID de Alumno', alumnos.nombre AS 'Nombre', alumnos.apellido AS 'Apellido', alumnos.fecha_nacimiento AS 'Fecha de Nacimiento', alumnos.direccion AS 'Direccion', alumnos.email AS 'Email', alumnos.telefono AS 'Telefono', cursos.anio AS 'Año', cursos.division AS 'Division', cursos.turno AS 'Turno', cursos.id_curso as 'Id del Curso'
                FROM alumnos
                INNER JOIN cursos
                ON alumnos.anio = cursos.anio AND alumnos.division = cursos.division
                WHERE cursos.anio = '$anioSeleccionado' AND cursos.division = '$divisionSeleccionada'
                ORDER BY alumnos.id ASC";

            $result = $conexion->query($sql);

            if ($result->num_rows > 0) {
                echo '
                <table class="table table-bordered table-striped">
                        <thead>
                            <tr class="table-dark">
                                <th scope="row">ID de Alumno</th>
                                <th scope="row">Nombre</th>
                                <th scope="row">Apellido</th>
                                <th scope="row">Fecha de Nacimiento</th>';
                                
                if($_SESSION['id_rol'] === 1 or $_SESSION['id_rol'] === 2){
                    echo '<th scope="row">Dirección</th>
                        <th scope="row">Email</th>
                        <th scope="row">Teléfono</th>';
                }
                echo '<th scope="row">Año</th>
                    <th scope="row">División</th>
                    <th scope="row">Turno</th>
                    <th scope="row">ID del Curso</th>
                    <th scope="row">Opciones</th>
                </tr>
            </thead>
            <tbody style="background-color: #D4C0A5;">';

                while ($row = $result->fetch_assoc()) {
                    echo '<tr class="table">
                            <td style="color: black;">' . $row["ID de Alumno"] . '</td>
                            <td style="color: black;">' . $row["Nombre"] . '</td>
                            <td style="color: black;">' . $row["Apellido"] . '</td>
                            <td style="color: black;">' . $row["Fecha de Nacimiento"] . '</td>';

                    if($_SESSION['id_rol'] === 1 or $_SESSION['id_rol'] === 2){
                        echo' <td style="color: black;">' . $row["Direccion"] . '</td>
                            <td style="color: black;">' . $row["Email"] . '</td>
                            <td style="color: black;">' . $row["Telefono"] . '</td>';
                    }   
                        echo '<td style="color: black;">' . $row["Año"] . '</td>
                            <td style="color: black;">' . $row["Division"] . '</td>
                            <td style="color: black;">' . $row["Turno"] . '</td>
                            <td style="color: black;">' . $row["Id del Curso"] . '</td>
                            <td>';

                            if($_SESSION['id_rol'] === 1 or $_SESSION['id_rol'] === 2){
                                echo '<a href="editar_alumno.php?id=' . $row["ID de Alumno"] . '" class="btn btn-primary">Editar</a>
                                    <br><br>
                                    <a href="eliminar_alumno.php?id=' . $row["ID de Alumno"] . '" class="btn btn-danger">Eliminar</a>
                                    <br><br>';
                            }

                            if($_SESSION['email'] === $row["Email"]){
                                echo '<button type="button" class="btn btn-info" data-mdb-toggle="modal" data-mdb-target="#modalNotas" data-alumno-id="'. $row["ID de Alumno"] .'" data-alumno-nombre="' . $row["Nombre"] . '" data-alumno-apellido="' . $row["Apellido"] . '">Ver Notas</button>';
                            } else if($_SESSION['id_rol'] === 1 or $_SESSION['id_rol'] === 2){
                                echo '<button type="button" class="btn btn-info" data-mdb-toggle="modal" data-mdb-target="#modalNotas" data-alumno-id="'. $row["ID de Alumno"] .'" data-alumno-nombre="' . $row["Nombre"] . '" data-alumno-apellido="' . $row["Apellido"] . '">Ver Notas</button>';
                                
                            }else{
                                echo 'No disponible';
                            }
                        echo '</td>
                        </tr>';
                    
                }

                echo '</tbody></table>';
            } else {
                echo '<div class="card" style="width: auto;">
                        <div class="card-body">
                            <h5 class="card-title">No se encontraron alumnos, intente con otro año y division.</h5>

                        </div>
                    </div>';
            }

            if($_SESSION['id_rol'] === 1 or $_SESSION['id_rol'] === 2){
                echo '<br>
                    <a href="agregar_alumno.php" class="btn btn-success mb-5">Agregar Alumno</a>';
            }

            $conexion->close();
        ?>
        

    </div>

    <div class="modal fade" id="modalNotas" tabindex="-1" aria-labelledby="modalNotas" aria-hidden="true">
        <div class="modal-dialog" style="max-width: 60%; max-height: 60vh;">

            <div class="modal-content">
                <div class="modal-header" id="modalNotasTitulo">
                        
                </div>
                <div class="modal-body" id="notasAlumno" style="max-height: 60vh; overflow-y: auto;"></div>

                <div class="modal-footer" id="modalFooter">
                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Cerrar</button>    
                </div>
            </div>
        </div>
    </div>
    
    
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>

    <script>
    $(document).ready(function() {
        $('#modalNotas').on('show.bs.modal', function(e) {
            var alumnoId = $(e.relatedTarget).data('alumno-id');
            var alumnoNombre = $(e.relatedTarget).data('alumno-nombre');
            var alumnoApellido = $(e.relatedTarget).data('alumno-apellido');
            var modalHeader = document.getElementById("modalNotasTitulo");
            var modalFooter = document.getElementById("modalFooter");
            
            <?php
            // Verificar el id_rol en PHP
            if ($_SESSION['id_rol'] === 1 || $_SESSION['id_rol'] === 2) {
                echo '
                // Realizar una solicitud AJAX para obtener las notas del alumno
                $.ajax({
                    type: "GET",
                    url: "obtener_notas.php",
                    data: { alumno_id: alumnoId },
                    success: function(response) {
                        $("#notasAlumno").html(response);
                        modalHeader.innerHTML = "<h4 class=\'modal-title\'>Notas de " + alumnoNombre + " " + alumnoApellido + "</h4><button type=\'button\' class=\'btn-close\' data-mdb-dismiss=\'modal\' aria-label=\'Close\'></button>";
                        modalFooter.innerHTML = "<a href=\'agregar_nota.php?id=" + alumnoId + "\' class=\'btn btn-primary\'>Agregar Notas</a><button type=\'button\' class=\'btn btn-secondary\' data-mdb-dismiss=\'modal\'>Cerrar</button>";
                    },
                    error: function() {
                        $("#notasAlumno").html("Error al cargar las notas.");
                    }
                });
                ';
            } else {
                echo '
                // Realizar una solicitud AJAX para obtener las notas del alumno (sin botón Agregar Notas)
                $.ajax({
                    type: "GET",
                    url: "obtener_notas.php",
                    data: { alumno_id: alumnoId },
                    success: function(response) {
                        $("#notasAlumno").html(response);
                        modalHeader.innerHTML = "<h4 class=\'modal-title\'>Notas de " + alumnoNombre + " " + alumnoApellido + "</h4><button type=\'button\' class=\'btn-close\' data-mdb-dismiss=\'modal\' aria-label=\'Close\'></button>";
                        // No mostramos el botón Agregar Notas para id_rol igual a 3
                        modalFooter.innerHTML = "<button type=\'button\' class=\'btn btn-secondary\' data-mdb-dismiss=\'modal\'>Cerrar</button>";
                    },
                    error: function() {
                        $("#notasAlumno").html("Error al cargar las notas.");
                    }
                });
                ';
            }
            ?>
        });
    });
    </script>
    <script>
        setTimeout(function() {
        var modal = new mdb.Modal(document.getElementById("modals"));
        modal.show();
        }, 300);
    </script>
</body>
</html>