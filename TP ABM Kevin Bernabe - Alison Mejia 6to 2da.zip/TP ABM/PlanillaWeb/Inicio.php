<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
    rel="stylesheet"
    />

    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">
    
    <title>Gral. Jose de San Martin</title>

</head>
<body style="background-color: #0F2D47;">
    <nav class="navbar navbar-expand-lg" style="background-color: #307AB4;">
        <div class="container-fluid d-flex justify-content-between">
            <img src="imagenes\logo.png" style="height: 150px; margin-left: 50px;">

            <div class="text-center">
                <h1 style="color: #D4C0A5;"><strong><em>"General Jose De San Martin"</strong></em></h1>
                <h2 style="color: #D4C0A5;"><strong><em>Escuela Tecnica Nº 32 D.E. 14</strong></em></h2>
            </div>

            <button
            class="navbar-toggler"
            type="button"
            data-mdb-toggle="collapse"
            data-mdb-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
            >
                <i class="fas fa-bars"></i>
            </button>

            <div class="d-flex align-items-center">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <div class="d-flex align-items-center">
                                <i style="color: #D4C0A5;" class="fas fa-circle-user fa-7x"></i>
                                <div style="margin-right: 50px;" class="text-center">
                                    <a href="Login.php" class="nav-link"><h2 style="color: #D4C0A5;">Iniciar Sesion</h2></a>
                                    <a href="registro.php" class="nav-link"><h2 style="color: #D4C0A5;">Crear Cuenta</h2></a>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <br>

    <div class="container">
        <div class="row">
            <div class="col">
                <img src="imagenes\escuela.jpg" style="height: 400px; margin-left:50px;" class="">    
            </div>
            
            <div class="col">
                <h3 style="color: #D4C0A5;">Nuestras especialidades:</h3>

                <div class="row mb-5">
                    <div class="col text-center">
                        <img src="imagenes\tecnico mecanico.png" style="height: 120px;">
                        <h5 style="color: #D4C0A5;">"Tecnico en Mecanico"</h5>
                    </div>
                        
                    <div class="col text-center">
                        <img src="imagenes\computacion.png" style="height: 120px;">
                        <h5 style="color: #D4C0A5;">"Tecnico en Computacion"</h5>
                    </div>

                    <div class="col text-center">
                        <img src="imagenes\automotores.avif" style="height: 120px;">
                        <h5 style="color: #D4C0A5;">"Tecnico en Automotores"</h5>
                    </div>
                </div>

                <h4 class="text-center" style="color: #D4C0A5;">Esta página está destinada a los preceptores y maestros de la escuela, para que puedan controlar a los alumnos que se encuentren dentro de los determinados años y divisiones. Los alumnos tambien podran consultar sus notas de materias determinadas.</h4>
                <h4 class="text-center mb-5" style="color: #D4C0A5;">Inicie sesión para poder tener acceso a la planilla web</h4>    
            </div>
        </div>
    </div>
    
    <footer class="text-center text-lg-start footer" style="background-color: #307AB4;">
        <section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
            <div class="container text-center text-md-start mt-1">
                <div class="row mt-3 text-center">
                    <div class="col-md-4 col-lg-3 col-xl-4 mx-auto mb-md-0 mb-4">
                        <!-- Links -->
                        <h4 style="color: #D4C0A5;" class="text-uppercase fw-bold mb-4">
                            Contacto
                        </h4>    
                        <h4 style="color: #D4D1CE;">
                            <i class="fas fa-envelope"></i>
                            ofdealumnos32@gmail.com
                        </h4>
                        <h4 style="color: #D4D1CE;">
                            <i class="fas fa-phone"></i>
                            4551-9121 4555-4026/4034
                        </h4>
                    </div>

                    <div class="col-md-2 col-lg-2 col-xl-3 mx-auto mb-4">
                        <!-- Links -->
                        <h4 style="color: #D4C0A5;" class="text-uppercase fw-bold mb-4">
                            Redes Sociales
                        </h4>
                        <a href="https://www.instagram.com/la.gloriosa.32/"><i style="color: pink;" class="fab fa-instagram fa-3x me-3"></i></a> 
                        <a href=""><i style="color: red;" class="fab fa-youtube fa-3x me-3"></i></a> 
                        <a href="https://www.facebook.com/groups/tecnica32/?locale=es_LA"><i style="color: blue;" class="fab fa-facebook fa-3x"></i></a>
                    </div>

                    <div class="col-md-2 col-lg-2 col-xl-5 mx-auto mb-4">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13139.225808851852!2d-58.4548736!3d-34.5837636!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcb5e42e4f1e1d%3A0x7074017081bcbe1d!2sEscuela%20T%C3%A9cnica%2032%20%22General%20Jos%C3%A9%20de%20San%20Mart%C3%ADn%22%20(La%20Gloriosa%2032)!5e0!3m2!1ses-419!2sar!4v1686436973034!5m2!1ses-419!2sar" width="500" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <h5 style="color: #D4C0A5;">Dirección: Teodoro García 3899, C1427ECG CABA</h5>
                    </div>
                </div>
            </div>
        </section>
    </footer>
    
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
    
</body>
</html>
