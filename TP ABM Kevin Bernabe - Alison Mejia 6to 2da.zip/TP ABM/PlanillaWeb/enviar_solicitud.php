<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
    rel="stylesheet"
    />

    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">

    <title>Gral. Jose de San Martin</title>
</head>

<body style="background-color: #0F2D47;">

    <?php
    session_start();
    if (isset($_GET["rol"])) {
        $rolId = $_GET["rol"];

        include("conexion.php");

        if ($rolId === '1') {
            $rol_solicitado = 'Administrador';
        } elseif ($rolId === '2') {
            $rol_solicitado = 'Profesor / Preceptor';
        }

        $consulta_sql = "SELECT * FROM usuario WHERE id_rol = ?";
        $stmt = $conexion->prepare($consulta_sql);
        $stmt->bind_param("i", $rolId);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $stmt->close();

        if ($resultado->num_rows > 0) {
            while ($row = $resultado->fetch_assoc()) {
                $remitente_id = $_SESSION['ID'];
                $destinatario_id = $row['ID'];
                $titulo = 'Solicitud Cambio de Rol del usuario ' . $_SESSION['email'];
                $contenido = 'El usuario: <b>' . $_SESSION['email'] . '</b>, de Nombre y Apellido: <b>' . $_SESSION['nombre'] . ' ' . $_SESSION['apellido'] . '</b>, de ID: ' . $_SESSION['ID'] . ' ha solicitado aumento de rol a <b>' . $rol_solicitado . '</b>. Esta a la espera de su respuesta.';

                $sql = "INSERT INTO mensajes (remitente_id, destinatario_id, titulo, contenido) VALUES (?, ?, ?, ?)";
                $stmt = $conexion->prepare($sql);
                $stmt->bind_param("iiss", $remitente_id, $destinatario_id, $titulo, $contenido);
                $stmt->execute();
                $stmt->close();

                echo '<div class="modal fade" id="miModal" tabindex="-1" role="dialog" aria-labelledby="miModalLabel" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="miModalLabel">¡Solicitud Enviada!</h5>
                                </div>
                                <div class="modal-body">
                                    <p>Un mensaje ha sido enviado con su solicitud de cambio de rol a uno de los administradores. Ahora deberá esperar la respuesta de los administradores ante su solicitud aceptando o rechazando su solicitud.</p>
                                    <p>¡Muchas Gracias!</p>
                                </div>
                                <div class="modal-footer">
                                    <a href="perfil.php" type="button" class="btn btn-danger">Volver</a>
                                </div>
                            </div>
                        </div>
                    </div>';
            }
        } else {
            echo '<div class="modal fade" id="miModal" tabindex="-1" role="dialog" aria-labelledby="miModalLabel" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="miModalLabel">¡Solicitud NO enviada!</h5>
                            </div>
                            <div class="modal-body">
                                No se pudo enviar el mensaje. Ha ocurrido un error.
                            </div>
                            <div class="modal-footer">
                                <a href="recuperar_contraseña.php" type="button" class="btn btn-danger">Volver a intentar</a>
                            </div>
                        </div>
                    </div>
                </div>';
        }
        $conexion->close();
    }
    ?>


    <script>
        setTimeout(function() {
        var modal = new mdb.Modal(document.getElementById('miModal'));
        modal.show();
        }, 500);
    </script>

    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
</body>
</html>