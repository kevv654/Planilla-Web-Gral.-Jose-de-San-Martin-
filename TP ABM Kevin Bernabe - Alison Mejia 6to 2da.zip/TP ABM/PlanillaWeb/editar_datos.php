<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    rel="stylesheet"
    />
    <!-- Google Fonts -->
    <link
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
    rel="stylesheet"
    />
    <!-- MDB -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css"
    rel="stylesheet"
    />

    <link rel="icon" href="imagenes\icono.ico" type="image/x-icon">

    <title>Gral. Jose de San Martin</title>
</head>
<body style="background-color: #0F2D47;">

<?php
session_start();
?>

    <form action="procesos.php" class="intro" method="POST">
        <div class="mask d-flex align-items-center h-100">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card" style="border-radius: 1rem; background-color:#307AB4;">
                            <div class="card-body p-5 text-center" >
        
                                <div class="my-md-0 pb-0">

                                    <div class="position-absolute top-0 start-0" style="width:120px; margin-left: 20px; margin-top: 20px;">
                                        <a style="color:#D4C0A5;" href="#" onclick="history.back(); return false;"><i style="float:left;" class="fas fa-angles-left fa-2x"></i><h3>Volver</h3></a>
                                    </div>

                                    <h1 class="fw-bold mb-2" style="color:#D4C0A5;">Editar Datos</h1> 
                                    <h6 class="mb-4" style="color:#D4C0A5;">Los siguientes datos estan disponibles para el cambio. Sea consciente y cambie sus datos con cuidado.</h6> 

                                    <div class="row mb-4">
                                        <div class="col">
                                            <div class="form-outline">
                                                <input style="background-color:#D4C0A5" type="email" id="email" class="form-control form-control-lg" name="editar_email" value="<?php echo''. $_SESSION['email'].''; ?>" required/>
                                                <label class="form-label" for="email">Email</label>
                                            </div>
                                        </div>

                                        <div class="col">
                                            <div class="form-outline">
                                                <input style="background-color:#D4C0A5" type="number" id="telefono" class="form-control form-control-lg" name="editar_telefono" value="<?php echo''. $_SESSION['telefono'].''; ?>" required/>
                                                <label class="form-label" for="telefono">Telefono</label>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row mb-4">

                                        <div class="col">
                                            <div class="form-outline">
                                                <input style="background-color:#D4C0A5" type="password" id="contraseña" minlength="8" pattern="^(?=.*\d)(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$" class="form-control form-control-lg" name="editar_contraseña"/>
                                                <label class="form-label" for="contraseña">Contraseña(8 carac./!@#$%^&*/Num.)</label>
                                            </div>
                                        </div>

                                        <div class="col">
                                            <div class="form-outline">
                                                <input style="background-color:#D4C0A5" type="password" id="confirmacion_contraseña" class="form-control form-control-lg" name="editar_confirmacion_contraseña"/>
                                                <label class="form-label" for="confirmacion_contraseña">Confirmar Contraseña</label>
                                            </div>
                                        </div>

                                    </div>
        
                                    <button style="background-color:#D7D1D7" class="btn btn-lg btn-rounded gradient-custom text-body px-5 mb-4" type="submit">Ingresar</button>
        
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="modal fade" id="miModal" tabindex="-1" role="dialog" aria-labelledby="miModalLabel" aria-hidden="true" data-mdb-backdrop="static" data-mdb-keyboard="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="miModalLabel"><b>Bienvenido/a <b><?php echo ''.$_SESSION['nombre'].' '.$_SESSION['apellido'].''; ?></b></b></h5>
                    <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Cerrar"></button>
                </div>

                <div class="modal-body">
                    <p>Ahora mismo se encuentra en el "Editor de sus Datos Personales".</p>
                    <p>Tendra la opcion de editar su <b>Número telefonico</b> y <b>Email o Correo Electronico </b>(Tenga muy en cuenta que si cambia su correo electonico la proxima vez que quiera ingresar <b>DEBERA HACERLO CON EL CORREO QUE INGRESO AQUI</b>, y preferentemente, use su contacto REAL de modo que podamos seguir en contacto con usted).</p>
                    <p>Si desea cambiar su contraseña simplemente establezca una nueva completando los campos correspondientes y podra ingresar con dicha contraseña nueva. Si no lo desea, no ingrese nada.</p>
                    <p><b>En caso de no querer cambiar algun dato en particular, simplemente deje el campo con su valor original.</b></p>
                    <p>-------------------------------------------------------------------------------------------------</p>
                    <p>Si ingreso aqui desde la pestaña de <b>Recuperar Contraseña</b>, asegurese de llenar el campo de contraseña y confirmela, de lo contrario permanecera la contraseña original.</p>
                    <p>Muchas Gracias!</p>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-mdb-dismiss="modal">Entendido</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        setTimeout(function() {
        var modal = new mdb.Modal(document.getElementById('miModal'));
        modal.show();
        }, 500);
    </script>

    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
</body>

</html>