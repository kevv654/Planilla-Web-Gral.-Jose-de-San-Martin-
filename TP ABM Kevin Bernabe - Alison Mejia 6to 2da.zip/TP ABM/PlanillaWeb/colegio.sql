
mysql -h localhost -u root -p 


DROP database if EXISTS colegio;
CREATE DATABASE colegio;
USE colegio;

CREATE TABLE alumnos(
  id INT(6) AUTO_INCREMENT,
  nombre VARCHAR(50),
  apellido VARCHAR(50),
  fecha_nacimiento DATE ,
  direccion VARCHAR(50),
  email VARCHAR(50),
  telefono VARCHAR(20),
  anio int(6),
  division int(6),
  primary KEY(id)
);

INSERT INTO alumnos (nombre, apellido, fecha_nacimiento, direccion, email, telefono, anio, division)
VALUES ('Juan', 'Pérez', '1995-08-10', 'Calle 123', 'juan@example.com', '123456789', 5, 5);

INSERT INTO alumnos (nombre, apellido, fecha_nacimiento, direccion, email, telefono, anio, division)
VALUES ('María', 'Gómez', '1996-02-15', 'Avenida 456', 'maria@example.com', '987654321', 5, 5);

INSERT INTO alumnos (nombre, apellido, fecha_nacimiento, direccion, email, telefono, anio, division)
VALUES ('Pedro', 'López', '1997-11-20', 'Plaza 789', 'pedro@example.com', '456789123', 5, 5);

INSERT INTO alumnos (nombre, apellido, fecha_nacimiento, direccion, email, telefono, anio, division)
VALUES ('Ana', 'Rodríguez', '1998-04-25', 'Paseo 987', 'ana@example.com', '321654987', 5, 5);

INSERT INTO alumnos (nombre, apellido, fecha_nacimiento, direccion, email, telefono, anio, division)
VALUES ('Carlos', 'Fernández', '1999-09-30', 'Carrera 654', 'carlos@example.com', '789321654', 5, 5);

INSERT INTO alumnos (nombre, apellido, fecha_nacimiento, direccion, email, telefono, anio, division)
VALUES ('Laura', 'Hernández', '2000-06-05', 'Camino 321', 'laura@example.com', '654987321', 5, 5);

INSERT INTO alumnos (nombre, apellido, fecha_nacimiento, direccion, email, telefono, anio, division)
VALUES ('Miguel', 'García', '2001-01-10', 'Autopista 789', 'miguel@example.com', '321987654', 5, 5);

INSERT INTO alumnos (nombre, apellido, fecha_nacimiento, direccion, email, telefono, anio, division)
VALUES ('Sofía', 'Martínez', '2002-08-15', 'Callejón 456', 'sofia@example.com', '987321654', 5, 5);

INSERT INTO alumnos (nombre, apellido, fecha_nacimiento, direccion, email, telefono, anio, division)
VALUES ('Luis', 'Sánchez', '2003-03-20', 'Avenida 789', 'luis@example.com', '654321987', 5, 5);

INSERT INTO alumnos (nombre, apellido, fecha_nacimiento, direccion, email, telefono, anio, division)
VALUES ('Elena', 'López', '2004-10-25', 'Plaza 123', 'elena@example.com', '321654789', 5, 5);


CREATE TABLE cursos (
    id_curso INT(6) AUTO_INCREMENT,
    anio int(6),
    division int(6),
    turno varchar(50),
    PRIMARY KEY(id_curso)
);

INSERT INTO cursos VALUES
(1, 1, 1, 'Mañana'),
(2, 1, 2, 'Mañana'),
(3, 1, 3, 'Mañana'),
(4, 1, 4, 'Mañana'),
(5, 1, 5, 'Mañana'),
(6, 1, 6, 'Tarde'),
(7, 1, 7, 'Tarde'),
(8, 1, 8, 'Tarde'),
(9, 1, 9, 'Tarde'),
(10, 1, 10, 'Tarde'),

(11, 2, 1, 'Mañana'),
(12, 2, 2, 'Mañana'),
(13, 2, 3, 'Mañana'),
(14, 2, 4, 'Mañana'),
(15, 2, 5, 'Mañana'),
(16, 2, 6, 'Tarde'),
(17, 2, 7, 'Tarde'),
(18, 2, 8, 'Tarde'),
(19, 2, 9, 'Tarde'),
(20, 2, 10, 'Tarde'),

(21, 3, 1, 'Mañana'),
(22, 3, 2, 'Mañana'),
(23, 3, 3, 'Mañana'),
(24, 3, 4, 'Mañana'),
(25, 3, 5, 'Mañana'),
(26, 3, 6, 'Tarde'),
(27, 3, 7, 'Tarde'),
(28, 3, 8, 'Tarde'),
(29, 3, 9, 'Tarde'),
(30, 3, 10, 'Tarde'),

(31, 4, 1, 'Mañana'),
(32, 4, 2, 'Mañana'),
(33, 4, 3, 'Mañana'),
(34, 4, 4, 'Mañana'),
(35, 4, 5, 'Mañana'),
(36, 4, 6, 'Tarde'),
(37, 4, 7, 'Tarde'),
(38, 4, 8, 'Tarde'),
(39, 4, 9, 'Vespertino'),
(40, 4, 10, 'Vespertino'),

(41, 5, 1, 'Mañana'),
(42, 5, 2, 'Vespertino'),
(43, 5, 3, 'Vespertino'),
(44, 5, 4, 'Vespertino'),
(45, 5, 5, 'Mañana'),
(46, 5, 6, 'Mañana'),
(47, 5, 7, 'Tarde'),
(48, 5, 8, 'Vespertino'),
(49, 5, 9, 'Tarde'),
(50, 5, 10, 'Tarde'),

(51, 6, 1, 'Mañana'),
(52, 6, 2, 'Vespertino'),
(53, 6, 3, 'Mañana'),
(54, 6, 4, 'Tarde'),
(55, 6, 5, 'Vespertino'),
(56, 6, 6, 'Tarde'),
(57, 6, 7, 'Mañana'),
(58, 6, 8, 'Tarde'),
(59, 6, 9, 'Vespertino'),
(60, 6, 10, 'Mañana');

CREATE TABLE notas (
  id INT(6) AUTO_INCREMENT,
  alumno_id INT(6),
  asignatura VARCHAR(50),
  nota DECIMAL(5, 2),
  observaciones VARCHAR(200),
  PRIMARY KEY(id),
  FOREIGN KEY (alumno_id) REFERENCES alumnos(id) ON DELETE CASCADE
);


CREATE TABLE usuario(
  ID int(11) NOT NULL AUTO_INCREMENT,
  nombre varchar(100) NOT NULL,
  apellido varchar(100) NOT NULL,
  fnacimiento date NOT NULL,
  genero varchar(50) NOT NULL,
  email varchar(50) NOT NULL,
  telefono int(15) NOT NULL,
  contrasenia varchar(50) NOT NULL,
  id_rol int(3) NOT NULL,
  primary key(ID)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO usuario (nombre, apellido, fnacimiento, genero, email, telefono, contrasenia, id_rol) 
VALUES ("Kevin", "Bernabe", "2004-10-10", "Masculino", "kevin.bernabeet32@gmail.com", 1156930232, "21232f297a57a5a743894a0e4a801fc3" /*admin*/, 1);

INSERT INTO usuario (nombre, apellido, fnacimiento, genero, email, telefono, contrasenia, id_rol) 
VALUES ("Kevin", "Bernabe", "2004-10-10", "Masculino", "bernabekevin4@gmail.com", 1156930232, "21232f297a57a5a743894a0e4a801fc3" /*admin*/, 3);



ALTER DATABASE tienda CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


CREATE TABLE tokens (
  ID INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  email VARCHAR(255) NOT NULL,
  token VARCHAR(50) NOT NULL,
  creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  usado BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (usuario_id) REFERENCES usuario(ID) on DELETE CASCADE
);


CREATE TABLE mensajes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  remitente_id INT,
  destinatario_id INT,
  titulo TEXT,
  contenido TEXT,
  fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (remitente_id) REFERENCES usuario(ID) on DELETE CASCADE,
  FOREIGN KEY (destinatario_id) REFERENCES usuario(ID) on DELETE CASCADE
);




SELECT alumnos.id AS "ID de Alumno", alumnos.nombre AS "Nombre", alumnos.apellido AS "Apellido", alumnos.fecha_nacimiento AS "Fecha de Nacimiento", alumnos.direccion AS "Direccion", alumnos.email AS "Email", alumnos.telefono AS "Telefono", cursos.anio AS "Año", cursos.division AS "Division", cursos.turno AS "Turno", cursos.id_curso as "Id del Curso"
FROM alumnos
INNER JOIN cursos
ON alumnos.anio = cursos.anio AND alumnos.division = cursos.division 
WHERE cursos.anio = 5 
ORDER BY id ASC; 

